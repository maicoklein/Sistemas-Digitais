#include <stdlib.h>
#include <stdio.h>
#include <math.h>

typedef struct xy
{
	float x;
	float y;

}  
	XY;
	XY * cria(float x, float y)
{
	XY * p=(XY*)malloc(sizeof(XY));

	p->x = x;
	p->y = y;

	return p;
}

void libera (XY * p)
{
	free(p);
}

void acessa (XY * p, float * x, float * y)
{
	*x = p->x;
	*y = p->y;

}

void atribui(XY * p, float x, float y)
{
	p->x = x;
	p->y = x;
}

float distancia(XY * p1, XY * p2)
{
	float dx= p2->x - p1->x;
	float dy= p2->y - p1->y;
	return sqrt(dx*dx + dy*dy);
}
