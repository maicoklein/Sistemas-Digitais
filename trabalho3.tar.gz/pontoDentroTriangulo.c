#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <xy.h>

typedef struct triangulo
{
	XY* ponto1;
	XY* ponto2;
	XY* ponto3;
} 

	Triangulo;
 
	Triangulo* tcria(float x, float y, float a, float b, float z, float c ) \\Ponteiro para os pontos do triangulo
{ 
	Triangulo* t=(Triangulo*)malloc(sizeof(Triangulo));
	t->ponto1=cria(x,y); \\Cria o ponto x,y
	t->ponto2=cria(a,b); \\Cria o ponto a,b
	t->ponto3=cria(z,c); \\Cria o ponto z,c
 	return t; 
}

float TrianArea( Triangulo* t, XY* ponto1)
{
	return fabs(((t->ponto2->x - t->ponto1->x)*(t->ponto3->y - t->ponto1->y) - (t->ponto3->x - t->ponto1->x) * (t->ponto2->y - t->ponto1->y))/2);
}

float TrianArea2(Triangulo* t, XY* ponto1)
{
	return fabs(((t->ponto2->x - t->ponto1->x)*(ponto1->y - t->ponto1->y) - (ponto1->x - t->ponto1->x) * (t->ponto2->y - t->ponto1->y))/2);
 
}

float TrianArea3(Triangulo* t, XY* ponto1)
{
	return fabs(((ponto1->x - t->ponto1->x)*(t->ponto3->y - t->ponto1->y) - (t->ponto3->x - t->ponto1->x) * (ponto1->y - t->ponto1->y))/2);
 
}
float TrianArea4(Triangulo* t, XY* ponto1)
{
	return fabs(((t->ponto2->x - ponto1->x)*(t->ponto3->y - ponto1->y) - (t->ponto3->x - ponto1->x) * (t->ponto2->y - ponto1->y))/2);
 
}

float PontoDentro(Triangulo* t, XY* ponto1)
{
	XY* z;
	z=0;
	float ABC = TrianArea(t,z);
	 
	float ACP = TrianArea2(t,ponto1);
 
	float ABP = TrianArea3(t,ponto1);
 
	float CPB = TrianArea4(t,ponto1);
 
	if(ABC == (ACP+ABP+CPB))
	{
	return 1;
	}
	else
	{
	return 0;
	}
}
 
	main()
{
 
	Triangulo* trian;
 
	XY* p;
	float x,y,a,b,c,z,l1,l2,l3,areat, resp;
 
	printf("Digite as coordenadas do ponto 1 (x,y): ");
	scanf("%f%f",&x,&y);
 
 	printf("Digite as coordenadas do ponto 2 (x,y): ");
	scanf("%f%f",&z,&a);
 
	printf("Digite as coordenadas do ponto 3 (x,y): ");
	scanf("%f%f",&b,&c);
	trian=tcria(x,y,z,a,b,c);
 
	printf("\nDigite um ponto: ");
	scanf("%f%f",&x, &y);
	p=0;
	areat = TrianArea(trian,p);
	p=cria(x,y);
 
 
	l1=distancia(trian->ponto1,trian->ponto2);
	l2=distancia(trian->ponto2,trian->ponto3);
	l3=distancia(trian->ponto1,trian->ponto3);
 
	resp = PontoDentro(trian,p);
 
	printf("Distancia ponto1 ponto2: %.2f",l1);
	printf("\nDistancia ponto2 ponto3: %.2f",l2);
	printf("\nDistancia ponto1 ponto3: %.2f",l3);
	printf("\nA area eh: %.2f",areat);
 
	if((l1+l2)>l3 && (l2+l3)>l1 && (l3+l1)>l2)
	{
		if(l1==l2 && l2==l3)
		{
		printf("\n");
		printf("\nEh triangulo\n"); \\Triangulo equilatero
 
		} 
		else if(l1==l2 || l2==l3 || l1==l3)
		{
		printf("\n");
		printf("\nEh triangulo\n"); \\Triangulo isosceles
		}
		else 
		{
		printf("\n");
		printf("\nEh triangulo\n"); \\Triangulo escaleno
		}
	} 
	else
	{
	printf("\n");
	printf("\nNao eh um triangulo\n");
	}

	if(resp == 1)
	{
	printf("O ponto esta dentro do triangulo.");
 	}
	else
	{
	printf("O ponto esta fora do triangulo.");
	}

}
